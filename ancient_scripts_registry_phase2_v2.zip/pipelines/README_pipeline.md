# DIWA-15 Pipeline Notes
- Broadcast `data/registry_master.jsonl` to DIWA-15, URS, RosettAI, USDT, URDT via FusionLinker.
- Attach `signmaps/*.json` per script for transliteration bootstraps.
- Enforce confidence thresholds MIN_CONF=0.72, MIN_COV=0.85.
