
import argparse, json, sys
def run(path, module):
    n=0
    for line in open(path,"r",encoding="utf-8"):
        try:
            o=json.loads(line)
            assert o.get("script_name")
            assert o.get("decipher_status") in {"decoded","partially_decoded","undecoded"}
            n+=1
        except Exception as e:
            print("[WARN] Skipped:", e, file=sys.stderr)
    print(f"[OK] Ingest simulated → module={module} items={n}")
if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--source",required=True)
    ap.add_argument("--module",required=True)
    a=ap.parse_args()
    run(a.source,a.module)
