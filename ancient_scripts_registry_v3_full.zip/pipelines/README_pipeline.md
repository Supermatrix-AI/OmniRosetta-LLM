
# DIWA-15 / FusionLinker Pipeline (v3 Full)
- Ingest: `python pipelines/ingest_diwa15.py --source data/registry_master.jsonl --module diwa-15-rosetta`
- Broadcast via FusionLinker (`pipelines/sync_fusionlinker.yaml`) to: DIWA-15 Rosetta, URS, RosettAI, USDT, URDT.
- Attach signmaps by script using `signmap_ref` in your app logic.
