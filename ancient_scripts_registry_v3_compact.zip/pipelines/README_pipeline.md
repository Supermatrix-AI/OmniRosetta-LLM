# DIWA-15 Compact Pipeline
Use ingest_diwa15.py to simulate broadcast.