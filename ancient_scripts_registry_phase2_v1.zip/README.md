# Ancient Scripts Registry — Phase II (v1)
Generated: 2025-10-19T11:57:28.012403Z

This pack seeds **Supermatrix-AI** (DIWA-15 Rosetta / URS / FusionLinker) with a unified registry of
**decoded**, **partially decoded**, and **undecoded** writing systems.

## Contents
- `schemas/script_schema.json` — minimal schema contract
- `data/decoded.jsonl` — fully deciphered scripts (~51)
- `data/partially_decoded.jsonl` — partials (~18)
- `data/undecoded.jsonl` — undecoded set (~15)
- `data/registry_master.jsonl` — concatenated view
- `pipelines/ingest_diwa15.py` — stub CLI to simulate ingestion
- `pipelines/sync_fusionlinker.yaml` — placeholder connectors config

## Usage
```bash
python pipelines/ingest_diwa15.py --source data/registry_master.jsonl --module diwa-15-rosetta
python pipelines/ingest_diwa15.py --source data/decoded.jsonl --module rosettAI
python pipelines/ingest_diwa15.py --source data/undecoded.jsonl --module urdt
```

> Notes:
> - This dataset is a **starter pack**. Extend entries with richer bibliographies, Unicode proposals,
>   sign lists, and token maps as you iterate. Keep `decipher_status` authoritative.
