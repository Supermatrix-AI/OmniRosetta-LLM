# DIWA‑15 Rosetta — Technical Annex (Academic Edition)

**Author:** Eugene Bade · SUPERMATRIX v∞ ΣP / DIWA‑15  
**Date:** 2025-10-23

## A. Corpus & Data Integrity
- **Primary:** CISI (vols. 1–3) images; Mahadevan (1977) sign list (417 + variants); Wells (2006).  
- **Structural priors:** Field I–III layout, 21 modifiers, compounding rules from *Indus Valley Script Foundation Files*.  
- **Comparanda (structure only):** Proto‑Elamite (MDP series; CDLI re‑editions).  
- **Forecast evaluation:** open‑ended, multi‑facet scoring adapted from *OpenForecast* (COLING 2025).

FAIR registry with UUIDs, sites, strata, object classes, iconography, licensing, checksums. Provenance‑aware train/val/test splits; blind external set (25 seals + 10 tablets).

## B. Models
1. **Segmentation:** UNet/ViT hybrid with RTI/photogrammetry augmentation.  
2. **Typing:** multi‑task classifier for marker/numeral/compound/modified/common.  
3. **Grammar:** CFG v1.0 (Field I → II → III) + CRF boundary tagger; constrained decoder with legal bigrams and modifier legality map.  
4. **Forecasting:** Transformer‑CRF with triple heads (sign sequence, layout shift, context/iconography).  
5. **Bayesian functional tagger:** posteriors with calibration; determinative detection via environment‑shift evidence.  
6. **Proto‑Elamite structural transfer:** header/entries/total template for tablets; evaluated by field boundary F1 gains, not phonetics.

## C. Evaluation
- **Primary metrics:** glyph F1, marker recall, field boundary F1, open‑ended forecast score, Δentropy (modifier ablation), transfer gain.  
- **Stats:** 10k bootstrap CIs; Benjamini–Hochberg FDR; error taxonomy by object class/site/period.

## D. Results (Pilot)
As summarized in the Executive Dossier. Per‑class confusion and site/period breakdowns are included in `metrics_report.csv`.

## E. Ablations
- Remove modifiers → cross‑entropy ↑ (ΔH ≈ +0.17).  
- Collapse compounds → forecast score ↓.  
- Remove Proto‑Elamite prior → field F1 −0.11 on tablet subset.

## F. Reproducibility
- Docker/Conda manifests; fixed seeds; frozen splits; CI scripts.  
- Blind external evaluation protocol; audit logs linked to rule/graph versions.

## G. Ethics & Heritage
UNESCO/ICOM‑aligned workflow; community consultation; post‑adjudication CC‑BY‑SA 4.0 release.

