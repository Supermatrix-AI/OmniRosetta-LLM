# DIWA‑15 Rosetta — Government & UNESCO Brief

**PI:** Eugene Bade · SUPERMATRIX v∞ ΣP / DIWA‑15  
**Date:** 2025-10-23

## Key Achievements
- Segmentation F1 **0.982** · Marker recall **0.954**  
- Field boundary F1 **0.873**  
- Open‑ended forecast score **0.84**  
- Modifier ablation Δentropy **+0.17** (derived meaning)  
- Proto‑Elamite structural transfer gain **+0.11** (tablets)  
- Corpus coverage **0.91** (CISI signs)

## Framework Diagram (textual)
Artifact → Imaging/Segmentation → Sign Graph → Grammar (CFG+CRF) → Forecasting (sign/layout/context) → Functional tags → Workbench/audit.

## Cultural Impact
Proto‑Elamite ↔ Indus structural convergence with regional semantic evolution; Tamil/Dravidian heritage engagement; open, ethical, reproducible preservation.

## Governance & Verification
- Pre‑registered metrics and blind external set.  
- Dockerized pipeline; checksums; audit logs.  
- Dual deposit: Tamil Nadu IVC Prize Portal + UNESCO repository.

